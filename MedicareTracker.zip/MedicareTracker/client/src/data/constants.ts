// Doctors data
export const DOCTORS = [
  { id: 1, name: "Dr. Anil Kumar", specialty: "General Physician", hospital: "AIIMS - Delhi" },
  { id: 2, name: "Dr. Priya Sharma", specialty: "Gynecologist", hospital: "Fortis Hospital - Mumbai" },
  { id: 3, name: "Dr. Ramesh Iyer", specialty: "Pediatrician", hospital: "Apollo Hospitals - Chennai" },
  { id: 4, name: "Dr. Mehul Shah", specialty: "Dermatologist", hospital: "Manipal Hospital - Bengaluru" },
  { id: 5, name: "Dr. Neha Kapoor", specialty: "Cardiologist", hospital: "Medanta - Gurugram" },
  { id: 6, name: "Dr. Arjun Rao", specialty: "Orthopedic", hospital: "KIMS - Hyderabad" },
  { id: 7, name: "Dr. Ananya Singh", specialty: "Psychologist", hospital: "Max Hospital - Noida" },
  { id: 8, name: "Dr. Vivek Menon", specialty: "Neurologist", hospital: "Narayana Health - Kolkata" },
  { id: 9, name: "Dr. Kavita Jain", specialty: "Infectious Diseases", hospital: "Ruby Hall Clinic - Pune" },
  { id: 10, name: "Dr. Rahul Desai", specialty: "Urologist", hospital: "Sir Ganga Ram Hospital - Delhi" },
];

// Hospitals data
export const HOSPITALS = [
  { 
    id: 1, 
    name: "AIIMS", 
    location: "Delhi", 
    state: "Delhi", 
    specialties: ["General Medicine", "Cardiology", "Neurology"]
  },
  { 
    id: 2, 
    name: "Apollo Hospitals", 
    location: "Chennai", 
    state: "Tamil Nadu", 
    specialties: ["Cardiology", "Orthopedics"]
  },
  { 
    id: 3, 
    name: "Fortis Hospital", 
    location: "Mumbai", 
    state: "Maharashtra", 
    specialties: ["Gynecology", "Pediatrics"]
  },
  { 
    id: 4, 
    name: "Manipal Hospital", 
    location: "Bengaluru", 
    state: "Karnataka", 
    specialties: ["Dermatology", "Oncology"]
  },
  { 
    id: 5, 
    name: "Medanta", 
    location: "Gurugram", 
    state: "Haryana", 
    specialties: ["Cardiology", "Gastroenterology"]
  },
  { 
    id: 6, 
    name: "KIMS", 
    location: "Hyderabad", 
    state: "Telangana", 
    specialties: ["Orthopedics", "Neurology"]
  },
  { 
    id: 7, 
    name: "Max Hospital", 
    location: "Noida", 
    state: "Uttar Pradesh", 
    specialties: ["Psychology", "Psychiatry"]
  },
  { 
    id: 8, 
    name: "Narayana Health", 
    location: "Kolkata", 
    state: "West Bengal", 
    specialties: ["Neurology", "Cardiology"]
  },
  { 
    id: 9, 
    name: "Ruby Hall Clinic", 
    location: "Pune", 
    state: "Maharashtra", 
    specialties: ["Infectious Diseases", "Internal Medicine"]
  },
  { 
    id: 10, 
    name: "Sir Ganga Ram Hospital", 
    location: "Delhi", 
    state: "Delhi", 
    specialties: ["Urology", "Nephrology"]
  },
];

// States and union territories in India
export const STATES = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
  "Lakshadweep",
  "Puducherry"
];

// Medical issues
export const MEDICAL_ISSUES = [
  "Fever",
  "Headache",
  "Vaccination",
  "Prenatal Care",
  "Skin Issues",
  "Heart Problems",
  "Bone/Joint Pain",
  "Mental Health",
  "Neurological Issues",
  "Infectious Disease"
];

// Time slots
export const TIME_SLOTS = [
  "09:00 AM",
  "09:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "12:00 PM",
  "12:30 PM",
  "02:00 PM",
  "02:30 PM",
  "03:00 PM",
  "03:30 PM",
  "04:00 PM",
  "04:30 PM"
];

// Map for time slot conversion
export const TIME_SLOT_MAP: Record<string, string> = {
  "09:00 AM": "09:00",
  "09:30 AM": "09:30",
  "10:00 AM": "10:00",
  "10:30 AM": "10:30",
  "11:00 AM": "11:00",
  "11:30 AM": "11:30",
  "12:00 PM": "12:00",
  "12:30 PM": "12:30",
  "02:00 PM": "14:00",
  "02:30 PM": "14:30",
  "03:00 PM": "15:00",
  "03:30 PM": "15:30",
  "04:00 PM": "16:00",
  "04:30 PM": "16:30"
};

export const TIME_SLOT_MAP_REVERSE: Record<string, string> = {
  "09:00": "09:00 AM",
  "09:30": "09:30 AM",
  "10:00": "10:00 AM",
  "10:30": "10:30 AM",
  "11:00": "11:00 AM",
  "11:30": "11:30 AM",
  "12:00": "12:00 PM",
  "12:30": "12:30 PM",
  "14:00": "02:00 PM",
  "14:30": "02:30 PM",
  "15:00": "03:00 PM",
  "15:30": "03:30 PM",
  "16:00": "04:00 PM",
  "16:30": "04:30 PM"
};
