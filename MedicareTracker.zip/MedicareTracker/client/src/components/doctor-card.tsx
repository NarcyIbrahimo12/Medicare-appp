import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface DoctorCardProps {
  id: number;
  name: string;
  specialty: string;
  hospital: string;
  rating?: number;
  reviews?: number;
}

const DoctorCard = ({ id, name, specialty, hospital, rating = 4.8, reviews = 200 }: DoctorCardProps) => {
  const [_, navigate] = useLocation();

  const handleBookAppointment = () => {
    navigate("/appointments/new");
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden p-4 flex flex-col items-center hover:shadow-lg transition-shadow">
      <div className="w-24 h-24 rounded-full bg-primary-100 mb-3 overflow-hidden flex items-center justify-center text-primary-600 text-lg font-bold">
        {name.split(' ')[1][0]}{name.split(' ')[2]?.[0] || ''}
      </div>
      <h3 className="font-bold text-lg">{name}</h3>
      <p className="text-primary-600 text-sm mb-2">{specialty}</p>
      <div className="flex items-center text-sm mb-3">
        <i className="ri-star-fill text-yellow-400"></i>
        <span className="ml-1">{rating}</span>
        <span className="text-neutral-400 ml-1">({reviews} reviews)</span>
      </div>
      <p className="text-neutral-500 text-sm mb-3 text-center">{hospital}</p>
      <Button 
        className="w-full mt-auto" 
        onClick={handleBookAppointment}
      >
        Book Appointment
      </Button>
    </div>
  );
};

export default DoctorCard;
