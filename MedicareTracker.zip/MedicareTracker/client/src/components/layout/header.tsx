import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Loader2, LogOut, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const [location] = useLocation();
  const { user, isLoading, logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-10 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center">
              <i className="ri-heart-pulse-line text-primary-500 text-3xl mr-2"></i>
              <h1 className="text-xl font-bold text-primary-800">Medicare</h1>
            </a>
          </Link>
          <nav className="flex items-center space-x-4">
            <Link href="/">
              <a className={`font-medium flex items-center py-2 px-1 border-b-2 ${
                location === "/" 
                  ? "border-primary-500 text-primary-600" 
                  : "border-transparent text-neutral-500 hover:text-primary-600"
              }`}>
                <i className="ri-home-4-line mr-1"></i>
                <span className="hidden md:inline">Home</span>
              </a>
            </Link>
            <Link href="/appointments">
              <a className={`font-medium flex items-center py-2 px-1 border-b-2 ${
                location === "/appointments" || location.startsWith("/appointments/")
                  ? "border-primary-500 text-primary-600" 
                  : "border-transparent text-neutral-500 hover:text-primary-600"
              }`}>
                <i className="ri-calendar-line mr-1"></i>
                <span className="hidden md:inline">My Appointments</span>
              </a>
            </Link>
            
            <div className="ml-4">
              {isLoading ? (
                <Button size="sm" variant="outline" disabled>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Loading...
                </Button>
              ) : user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="bg-primary-100 text-primary-600 text-xs">
                          {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="hidden md:inline">{user.name}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem disabled className="flex items-center">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleLogout} disabled={logoutMutation.isPending}>
                      {logoutMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          <span>Logging out...</span>
                        </>
                      ) : (
                        <>
                          <LogOut className="mr-2 h-4 w-4" />
                          <span>Log out</span>
                        </>
                      )}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link href="/auth">
                  <Button 
                    size="sm" 
                    variant={location === "/auth" ? "default" : "outline"}
                    className="flex items-center"
                  >
                    <User className="mr-2 h-4 w-4" />
                    <span>Login / Sign Up</span>
                  </Button>
                </Link>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
