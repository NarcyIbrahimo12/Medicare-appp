const Footer = () => {
  return (
    <footer className="bg-white border-t border-neutral-200 py-6 text-neutral-500">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <i className="ri-heart-pulse-line text-primary-500 text-2xl mr-2"></i>
            <h2 className="text-lg font-bold text-primary-800">Medicare</h2>
          </div>
          <div className="text-sm">
            <p>© {new Date().getFullYear()} Medicare. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
