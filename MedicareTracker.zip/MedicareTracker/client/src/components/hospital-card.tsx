import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface HospitalCardProps {
  id: number;
  name: string;
  location: string;
  state: string;
  specialties: string[];
  rating?: number;
  reviews?: number;
}

const HospitalCard = ({ id, name, location, state, specialties, rating = 4.5, reviews = 350 }: HospitalCardProps) => {
  const [_, navigate] = useLocation();

  const handleBookAppointment = () => {
    navigate("/appointments/new");
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-40 bg-primary-100 relative">
        <div className="absolute top-0 right-0 m-2 bg-primary-500 text-white text-xs px-2 py-1 rounded-full">
          Top Rated
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-1">{name}</h3>
        <p className="text-neutral-500 text-sm mb-2">{location}, {state}</p>
        <div className="flex items-center text-sm mb-3">
          <i className="ri-star-fill text-yellow-400"></i>
          <span className="ml-1">{rating}</span>
          <span className="text-neutral-400 ml-1">({reviews} reviews)</span>
        </div>
        <div className="flex flex-wrap gap-1 mb-3">
          {specialties.slice(0, 3).map((specialty, index) => (
            <span 
              key={index} 
              className="bg-primary-50 text-primary-700 text-xs px-2 py-1 rounded-full"
            >
              {specialty}
            </span>
          ))}
        </div>
        <Button 
          className="w-full" 
          onClick={handleBookAppointment}
        >
          Book Appointment
        </Button>
      </div>
    </div>
  );
};

export default HospitalCard;
