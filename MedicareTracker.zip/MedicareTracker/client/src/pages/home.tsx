import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue, 
} from "@/components/ui/select";
import { HOSPITALS, STATES, DOCTORS } from "@/data/constants";
import HospitalCard from "@/components/hospital-card";
import DoctorCard from "@/components/doctor-card";
import { useLocation } from "wouter";

const Home = () => {
  const [_, navigate] = useLocation();
  const [stateFilter, setStateFilter] = useState("all");
  const [specialtyFilter, setSpecialtyFilter] = useState("all");

  const handleCreateAppointment = () => {
    navigate("/appointments/new");
  };

  // Get unique specialties
  const specialties = Array.from(
    new Set(DOCTORS.map((doctor) => doctor.specialty))
  );

  // Filter hospitals based on state
  const filteredHospitals = HOSPITALS.filter(
    (hospital) => stateFilter === "all" || hospital.state === stateFilter
  );

  return (
    <div>
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg shadow-md p-6 mb-6 text-white">
        <div className="max-w-3xl">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Book Medical Appointments with Ease</h1>
          <p className="mb-4 text-primary-50">Connect with top hospitals and doctors across India for your healthcare needs</p>
          <Button 
            variant="secondary" 
            className="bg-white text-primary-700 hover:bg-primary-50"
            onClick={handleCreateAppointment}
          >
            Book Appointment
          </Button>
        </div>
      </div>

      {/* Filter Section */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <h2 className="text-lg font-semibold mb-4">Find Hospitals Near You</h2>
        <div className="flex flex-wrap gap-4">
          <div className="w-full md:w-1/3">
            <label htmlFor="state-filter" className="block text-sm font-medium text-neutral-500 mb-1">State/UT</label>
            <Select value={stateFilter} onValueChange={setStateFilter}>
              <SelectTrigger id="state-filter" className="w-full">
                <SelectValue placeholder="All States" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All States</SelectItem>
                {STATES.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="w-full md:w-1/3">
            <label htmlFor="specialty-filter" className="block text-sm font-medium text-neutral-500 mb-1">Specialty</label>
            <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
              <SelectTrigger id="specialty-filter" className="w-full">
                <SelectValue placeholder="All Specialties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Specialties</SelectItem>
                {specialties.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="w-full md:w-1/4 flex items-end">
            <Button className="w-full">
              Search
            </Button>
          </div>
        </div>
      </div>

      {/* Hospitals Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Top Hospitals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHospitals.slice(0, 3).map((hospital) => (
            <HospitalCard
              key={hospital.id}
              id={hospital.id}
              name={hospital.name}
              location={hospital.location}
              state={hospital.state}
              specialties={hospital.specialties}
            />
          ))}
        </div>
        <div className="text-center mt-4">
          <Button variant="link" className="text-primary-600 hover:text-primary-700">
            View All Hospitals <i className="ri-arrow-right-line align-middle ml-1"></i>
          </Button>
        </div>
      </div>

      {/* Doctors Section */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Top Doctors</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {DOCTORS.slice(0, 4).map((doctor) => (
            <DoctorCard
              key={doctor.id}
              id={doctor.id}
              name={doctor.name}
              specialty={doctor.specialty}
              hospital={doctor.hospital}
            />
          ))}
        </div>
        <div className="text-center mt-4">
          <Button variant="link" className="text-primary-600 hover:text-primary-700">
            View All Doctors <i className="ri-arrow-right-line align-middle ml-1"></i>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Home;
