import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { TIME_SLOT_MAP_REVERSE } from "@/data/constants";

const AppointmentConfirmation = () => {
  const { id } = useParams();
  const [_, navigate] = useLocation();

  const { data: appointment, isLoading } = useQuery({
    queryKey: [`/api/appointments/${id}`],
  });

  const handleViewAllAppointments = () => {
    navigate("/appointments");
  };

  const handleBookAnother = () => {
    navigate("/appointments/new");
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary-500 rounded-full border-t-transparent"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="text-center">
            <p className="text-lg font-medium text-red-500">Appointment not found</p>
            <Button className="mt-4" onClick={() => navigate("/appointments/new")}>
              Book a New Appointment
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Format the date
  const formattedDate = format(new Date(appointment.appointmentDate), "MMMM d, yyyy");
  
  // Get the formatted time
  const formattedTime = TIME_SLOT_MAP_REVERSE[appointment.appointmentTime] || appointment.appointmentTime;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="sm" 
          className="mr-3 text-neutral-500 hover:text-primary-600"
          onClick={handleViewAllAppointments}
        >
          <i className="ri-arrow-left-line text-xl"></i>
        </Button>
        <h1 className="text-2xl font-bold text-neutral-800">Appointment Confirmation</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="bg-green-50 border border-green-500 text-green-600 rounded-lg p-4 mb-6 flex items-start">
          <i className="ri-check-line text-xl mr-2 text-green-500"></i>
          <div>
            <p className="font-medium">Appointment successfully booked</p>
            <p className="text-sm">Your appointment has been confirmed. Please arrive 15 minutes before your scheduled time.</p>
          </div>
        </div>
        
        <div className="border-b border-neutral-200 pb-4 mb-4">
          <h2 className="text-lg font-semibold mb-4">Appointment Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-neutral-500">Doctor</p>
              <p className="font-medium text-neutral-800">{appointment.doctorName}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Specialty</p>
              <p className="font-medium text-neutral-800">{appointment.doctorSpecialty}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Hospital</p>
              <p className="font-medium text-neutral-800">{appointment.hospitalName}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Medical Issue</p>
              <p className="font-medium text-neutral-800">{appointment.illnessType}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Date</p>
              <p className="font-medium text-neutral-800">{formattedDate}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Time</p>
              <p className="font-medium text-neutral-800">{formattedTime}</p>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3 justify-between">
          <Button 
            variant="outline" 
            className="text-primary-600 border-primary-500 hover:bg-primary-50"
            onClick={handleViewAllAppointments}
          >
            View All Appointments
          </Button>
          <Button onClick={handleBookAnother}>
            Book Another Appointment
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AppointmentConfirmation;
