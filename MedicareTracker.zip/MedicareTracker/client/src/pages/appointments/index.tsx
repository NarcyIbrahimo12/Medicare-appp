import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { TIME_SLOT_MAP_REVERSE } from "@/data/constants";

const AppointmentsList = () => {
  const [_, navigate] = useLocation();
  const [filter, setFilter] = useState("all");

  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ['/api/appointments'],
  });

  const handleNewAppointment = () => {
    navigate("/appointments/new");
  };

  const getFilteredAppointments = () => {
    if (filter === "all") {
      return appointments;
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (filter === "upcoming") {
      return appointments.filter((appointment: any) => {
        const appointmentDate = new Date(appointment.appointmentDate);
        return appointmentDate >= today;
      });
    }
    
    if (filter === "past") {
      return appointments.filter((appointment: any) => {
        const appointmentDate = new Date(appointment.appointmentDate);
        return appointmentDate < today;
      });
    }
    
    if (filter === "cancelled") {
      return appointments.filter((appointment: any) => appointment.status === "cancelled");
    }
    
    return appointments;
  };

  const filteredAppointments = getFilteredAppointments();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-neutral-800">My Appointments</h1>
        <Button onClick={handleNewAppointment} className="flex items-center">
          <i className="ri-add-line mr-1"></i>
          New Appointment
        </Button>
      </div>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 border-b border-neutral-200">
          <div className="flex flex-wrap gap-3">
            <Button 
              size="sm"
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
            >
              All
            </Button>
            <Button 
              size="sm"
              variant={filter === "upcoming" ? "default" : "outline"}
              onClick={() => setFilter("upcoming")}
            >
              Upcoming
            </Button>
            <Button 
              size="sm"
              variant={filter === "past" ? "default" : "outline"}
              onClick={() => setFilter("past")}
            >
              Past
            </Button>
            <Button 
              size="sm"
              variant={filter === "cancelled" ? "default" : "outline"}
              onClick={() => setFilter("cancelled")}
            >
              Cancelled
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="inline-block animate-spin h-8 w-8 border-4 border-primary-500 rounded-full border-t-transparent"></div>
          </div>
        ) : (
          <>
            {filteredAppointments.length > 0 ? (
              <div>
                {filteredAppointments.map((appointment: any) => {
                  const appointmentDate = new Date(appointment.appointmentDate);
                  const formattedDate = format(appointmentDate, "d MMM");
                  const formattedTime = TIME_SLOT_MAP_REVERSE[appointment.appointmentTime] || appointment.appointmentTime;
                  
                  return (
                    <div key={appointment.id} className="border-b border-neutral-200 hover:bg-neutral-50 transition-colors">
                      <div className="p-4">
                        <div className="flex flex-wrap md:flex-nowrap gap-4 md:items-center">
                          <div className="w-full md:w-auto">
                            <div className="w-12 h-12 bg-primary-100 rounded-full flex flex-col items-center justify-center text-primary-800 font-medium text-center">
                              {formattedDate.split(' ')[0]}<br/>{formattedDate.split(' ')[1]}
                            </div>
                          </div>
                          <div className="flex-grow">
                            <div className="flex flex-wrap justify-between items-start">
                              <div>
                                <h3 className="font-medium text-neutral-800">{appointment.doctorName}</h3>
                                <p className="text-sm text-neutral-500">{appointment.doctorSpecialty} • {appointment.hospitalName}</p>
                              </div>
                              <div className={`text-xs py-1 px-2 rounded-full ${
                                appointment.status === "confirmed" 
                                  ? "bg-green-100 text-green-800" 
                                  : "bg-red-100 text-red-800"
                              }`}>
                                {appointment.status === "confirmed" ? "Confirmed" : "Cancelled"}
                              </div>
                            </div>
                            <div className="mt-2 flex flex-wrap items-center gap-x-4 text-sm text-neutral-600">
                              <div className="flex items-center">
                                <i className="ri-time-line mr-1"></i> {formattedTime}
                              </div>
                              <div className="flex items-center">
                                <i className="ri-nurse-line mr-1"></i> {appointment.illnessType}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2 md:flex-col">
                            <Button variant="outline" size="sm" className="text-primary-600 border-primary-500 hover:bg-primary-50">
                              Reschedule
                            </Button>
                            <Button variant="outline" size="sm">
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-4 text-center text-neutral-500">
                <p>You don't have any appointments yet.</p>
                <Button variant="link" className="mt-2 text-primary-600" onClick={handleNewAppointment}>
                  Book your first appointment
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AppointmentsList;
