import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiRequest } from "@/lib/queryClient";
import { STATES, MEDICAL_ISSUES, TIME_SLOTS, HOSPITALS, DOCTORS } from "@/data/constants";
import { queryClient } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { CalendarIcon } from "lucide-react";
import { insertAppointmentSchema } from "@shared/schema";

const formSchema = insertAppointmentSchema.extend({
  state: z.string().min(1, "State is required"),
});

type FormValues = z.infer<typeof formSchema>;

const NewAppointment = () => {
  const [_, navigate] = useLocation();
  const [selectedState, setSelectedState] = useState("");
  const [filteredHospitals, setFilteredHospitals] = useState(HOSPITALS);
  const [selectedHospital, setSelectedHospital] = useState<number | null>(null);
  const [selectedIllness, setSelectedIllness] = useState("");
  const [filteredDoctors, setFilteredDoctors] = useState(DOCTORS);
  const [availableSlots, setAvailableSlots] = useState<string[]>(TIME_SLOTS);

  // Get booked slots
  const { data: bookedSlots = [], isLoading: isLoadingSlots } = useQuery({
    queryKey: ['/api/appointments/booked-slots'],
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      state: "",
      hospitalId: 0,
      hospitalName: "",
      hospitalLocation: "",
      doctorId: 0,
      doctorName: "",
      doctorSpecialty: "",
      illnessType: "",
      appointmentDate: "",
      appointmentTime: "",
      status: "confirmed",
    },
  });

  // Create appointment mutation
  const createAppointment = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/appointments", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments/booked-slots'] });
      navigate(`/appointments/confirmation/${data.id}`);
    },
  });

  // Update filtered hospitals when state changes
  useEffect(() => {
    if (selectedState) {
      setFilteredHospitals(
        HOSPITALS.filter((hospital) => hospital.state === selectedState)
      );
    } else {
      setFilteredHospitals(HOSPITALS);
    }
  }, [selectedState]);

  // Update filtered doctors when hospital changes
  useEffect(() => {
    if (selectedHospital) {
      const hospital = HOSPITALS.find((h) => h.id === selectedHospital);
      if (hospital) {
        setFilteredDoctors(
          DOCTORS.filter((doctor) => doctor.hospital.includes(hospital.name))
        );
      }
    } else {
      setFilteredDoctors(DOCTORS);
    }
  }, [selectedHospital]);

  // Update available slots based on selected doctor, date and booked slots
  useEffect(() => {
    if (form.watch("doctorId") && form.watch("appointmentDate")) {
      // Filter out booked slots for this doctor and date
      const doctorId = form.watch("doctorId");
      const date = form.watch("appointmentDate");
      
      const doctorBookedSlots = bookedSlots.filter(
        (slot: any) => slot.doctorId === doctorId && slot.appointmentDate === date
      ).map((slot: any) => slot.appointmentTime);
      
      setAvailableSlots(
        TIME_SLOTS.filter((slot) => !doctorBookedSlots.includes(slot))
      );
    } else {
      setAvailableSlots(TIME_SLOTS);
    }
  }, [form.watch("doctorId"), form.watch("appointmentDate"), bookedSlots]);

  const handleStateChange = (value: string) => {
    setSelectedState(value);
    form.setValue("state", value);
  };

  const handleHospitalChange = (value: string) => {
    const hospitalId = parseInt(value);
    setSelectedHospital(hospitalId);
    
    const hospital = HOSPITALS.find((h) => h.id === hospitalId);
    if (hospital) {
      form.setValue("hospitalId", hospitalId);
      form.setValue("hospitalName", hospital.name);
      form.setValue("hospitalLocation", `${hospital.location}, ${hospital.state}`);
    }
  };

  const handleIllnessChange = (value: string) => {
    setSelectedIllness(value);
    form.setValue("illnessType", value);
  };

  const handleDoctorChange = (value: string) => {
    const doctorId = parseInt(value);
    const doctor = DOCTORS.find((d) => d.id === doctorId);
    if (doctor) {
      form.setValue("doctorId", doctorId);
      form.setValue("doctorName", doctor.name);
      form.setValue("doctorSpecialty", doctor.specialty);
    }
  };

  const onSubmit = (data: FormValues) => {
    createAppointment.mutate(data);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="sm" 
          className="mr-3 text-neutral-500 hover:text-primary-600"
          onClick={() => navigate("/")}
        >
          <i className="ri-arrow-left-line text-xl"></i>
        </Button>
        <h1 className="text-2xl font-bold text-neutral-800">Book a New Appointment</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Step 1: Select Location */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-neutral-800 flex items-center">
                <span className="bg-primary-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">1</span>
                Select Location
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State/UT</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={handleStateChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select State" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {STATES.map((state) => (
                            <SelectItem key={state} value={state}>
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Step 2: Select Hospital */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-neutral-800 flex items-center">
                <span className="bg-primary-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">2</span>
                Select Hospital
              </h2>
              <div className="grid grid-cols-1 gap-3">
                <FormField
                  control={form.control}
                  name="hospitalId"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value.toString()}
                          onValueChange={handleHospitalChange}
                          className="flex flex-col space-y-2"
                        >
                          {filteredHospitals.map((hospital) => (
                            <div key={hospital.id} className="relative flex border border-neutral-200 rounded-lg p-3 cursor-pointer hover:bg-primary-50 hover:border-primary-200 transition-colors">
                              <FormItem className="flex items-start m-0 space-x-3">
                                <FormControl>
                                  <RadioGroupItem value={hospital.id.toString()} className="sr-only peer" />
                                </FormControl>
                                <div className="w-5 h-5 rounded-full border-2 border-neutral-300 flex-shrink-0 peer-data-[state=checked]:border-primary-500 peer-data-[state=checked]:bg-primary-500 relative">
                                  <div className="absolute h-3 w-3 rounded-full bg-white top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 scale-0 peer-data-[state=checked]:scale-100" />
                                </div>
                                <div className="flex flex-col">
                                  <span className="font-medium text-neutral-800">{hospital.name}</span>
                                  <span className="text-sm text-neutral-500">{hospital.location}, {hospital.state}</span>
                                </div>
                              </FormItem>
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Step 3: Select Medical Issue */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-neutral-800 flex items-center">
                <span className="bg-primary-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">3</span>
                Medical Issue
              </h2>
              <FormField
                control={form.control}
                name="illnessType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type of Illness/Consultation</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={handleIllnessChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Issue" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {MEDICAL_ISSUES.map((issue) => (
                          <SelectItem key={issue} value={issue}>
                            {issue}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Step 4: Select Doctor */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-neutral-800 flex items-center">
                <span className="bg-primary-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">4</span>
                Select Doctor
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FormField
                  control={form.control}
                  name="doctorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value.toString()}
                          onValueChange={handleDoctorChange}
                          className="flex flex-col space-y-2"
                        >
                          {filteredDoctors.map((doctor) => (
                            <div key={doctor.id} className="relative flex border border-neutral-200 rounded-lg p-3 cursor-pointer hover:bg-primary-50 hover:border-primary-200 transition-colors">
                              <FormItem className="flex items-start m-0 space-x-3">
                                <FormControl>
                                  <RadioGroupItem value={doctor.id.toString()} className="sr-only peer" />
                                </FormControl>
                                <div className="w-5 h-5 rounded-full border-2 border-neutral-300 flex-shrink-0 peer-data-[state=checked]:border-primary-500 peer-data-[state=checked]:bg-primary-500 relative">
                                  <div className="absolute h-3 w-3 rounded-full bg-white top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 scale-0 peer-data-[state=checked]:scale-100" />
                                </div>
                                <div className="flex flex-grow">
                                  <div className="flex-shrink-0 mr-3">
                                    <div className="w-10 h-10 rounded-full bg-primary-100 overflow-hidden flex items-center justify-center text-primary-600 font-bold">
                                      {doctor.name.split(' ')[1][0]}{doctor.name.split(' ')[2]?.[0] || ''}
                                    </div>
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="font-medium text-neutral-800">{doctor.name}</span>
                                    <span className="text-sm text-neutral-500">{doctor.specialty}</span>
                                  </div>
                                </div>
                              </FormItem>
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Step 5: Select Date & Time */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-neutral-800 flex items-center">
                <span className="bg-primary-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">5</span>
                Select Date & Time
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="appointmentDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Appointment Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(new Date(field.value), "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value ? new Date(field.value) : undefined}
                            onSelect={(date) => field.onChange(date ? format(date, "yyyy-MM-dd") : "")}
                            disabled={(date) => 
                              date < new Date(new Date().setHours(0, 0, 0, 0))
                            }
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="appointmentTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Appointment Time</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                        disabled={!form.watch("appointmentDate") || !form.watch("doctorId")}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Time" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {availableSlots.map((slot) => (
                            <SelectItem key={slot} value={slot}>
                              {slot}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <div className="pt-4 flex justify-end">
              <Button 
                type="submit" 
                disabled={createAppointment.isPending}
              >
                {createAppointment.isPending ? "Booking..." : "Book Appointment"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
};

export default NewAppointment;
