import { users, type User, type InsertUser } from "@shared/schema";
import { 
  hospitals, 
  doctors, 
  appointments, 
  type Hospital, 
  type Doctor, 
  type Appointment, 
  type InsertHospital, 
  type InsertDoctor, 
  type InsertAppointment 
} from "@shared/schema";
import { HOSPITALS, DOCTORS } from "../client/src/data/constants";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Hospital methods
  getHospitals(): Promise<Hospital[]>;
  getHospitalsByState(state: string): Promise<Hospital[]>;
  getHospital(id: number): Promise<Hospital | undefined>;
  
  // Doctor methods
  getDoctors(): Promise<Doctor[]>;
  getDoctorsByHospital(hospitalId: number): Promise<Doctor[]>;
  getDoctorsBySpecialty(specialty: string): Promise<Doctor[]>;
  getDoctor(id: number): Promise<Doctor | undefined>;
  
  // Appointment methods
  getAppointments(): Promise<Appointment[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<Appointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  getBookedSlots(): Promise<Array<{doctorId: number, appointmentDate: string, appointmentTime: string}>>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private hospitals: Map<number, Hospital>;
  private doctors: Map<number, Doctor>;
  private appointments: Map<number, Appointment>;
  private userCurrentId: number;
  private hospitalCurrentId: number;
  private doctorCurrentId: number;
  private appointmentCurrentId: number;

  constructor() {
    this.users = new Map();
    this.hospitals = new Map();
    this.doctors = new Map();
    this.appointments = new Map();
    this.userCurrentId = 1;
    this.hospitalCurrentId = 1;
    this.doctorCurrentId = 1;
    this.appointmentCurrentId = 1;
    
    // Initialize with dummy data
    this.initHospitals();
    this.initDoctors();
  }

  private initHospitals() {
    HOSPITALS.forEach(hospital => {
      const h: Hospital = {
        id: hospital.id,
        name: hospital.name,
        location: hospital.location,
        state: hospital.state,
        specialties: hospital.specialties
      };
      this.hospitals.set(hospital.id, h);
      this.hospitalCurrentId = Math.max(this.hospitalCurrentId, hospital.id + 1);
    });
  }

  private initDoctors() {
    DOCTORS.forEach(doctor => {
      const hospitalName = doctor.hospital.split(' - ')[0];
      const locationName = doctor.hospital.split(' - ')[1];
      
      const d: Doctor = {
        id: doctor.id,
        name: doctor.name,
        specialty: doctor.specialty,
        hospital: doctor.hospital
      };
      this.doctors.set(doctor.id, d);
      this.doctorCurrentId = Math.max(this.doctorCurrentId, doctor.id + 1);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Hospital methods
  async getHospitals(): Promise<Hospital[]> {
    return Array.from(this.hospitals.values());
  }
  
  async getHospitalsByState(state: string): Promise<Hospital[]> {
    return Array.from(this.hospitals.values()).filter(
      (hospital) => hospital.state === state
    );
  }
  
  async getHospital(id: number): Promise<Hospital | undefined> {
    return this.hospitals.get(id);
  }
  
  // Doctor methods
  async getDoctors(): Promise<Doctor[]> {
    return Array.from(this.doctors.values());
  }
  
  async getDoctorsByHospital(hospitalId: number): Promise<Doctor[]> {
    const hospital = this.hospitals.get(hospitalId);
    if (!hospital) return [];
    
    return Array.from(this.doctors.values()).filter(
      (doctor) => doctor.hospital.includes(hospital.name)
    );
  }
  
  async getDoctorsBySpecialty(specialty: string): Promise<Doctor[]> {
    return Array.from(this.doctors.values()).filter(
      (doctor) => doctor.specialty === specialty
    );
  }
  
  async getDoctor(id: number): Promise<Doctor | undefined> {
    return this.doctors.get(id);
  }
  
  // Appointment methods
  async getAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).sort((a, b) => {
      // Sort by date (newest first)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async createAppointment(appointmentData: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentCurrentId++;
    const now = new Date();
    
    const appointment: Appointment = {
      ...appointmentData,
      id,
      createdAt: now,
      status: appointmentData.status || "confirmed" // Ensure status is never undefined
    };
    
    this.appointments.set(id, appointment);
    return appointment;
  }
  
  async updateAppointment(id: number, data: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...data };
    this.appointments.set(id, updatedAppointment);
    
    return updatedAppointment;
  }
  
  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }
  
  async getBookedSlots(): Promise<Array<{doctorId: number, appointmentDate: string, appointmentTime: string}>> {
    return Array.from(this.appointments.values())
      .filter(appointment => appointment.status === "confirmed")
      .map(appointment => ({
        doctorId: appointment.doctorId,
        appointmentDate: appointment.appointmentDate,
        appointmentTime: appointment.appointmentTime
      }));
  }
}

export const storage = new MemStorage();
