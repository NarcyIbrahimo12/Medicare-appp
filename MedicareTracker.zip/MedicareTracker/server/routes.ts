import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertAppointmentSchema } from "@shared/schema";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  // Get all hospitals
  app.get("/api/hospitals", async (req, res) => {
    const state = req.query.state as string | undefined;
    
    try {
      if (state) {
        const hospitals = await storage.getHospitalsByState(state);
        res.json(hospitals);
      } else {
        const hospitals = await storage.getHospitals();
        res.json(hospitals);
      }
    } catch (error) {
      console.error("Error fetching hospitals:", error);
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

  // Get a specific hospital
  app.get("/api/hospitals/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const hospital = await storage.getHospital(id);
      
      if (!hospital) {
        return res.status(404).json({ message: "Hospital not found" });
      }
      
      res.json(hospital);
    } catch (error) {
      console.error("Error fetching hospital:", error);
      res.status(500).json({ message: "Failed to fetch hospital" });
    }
  });

  // Get all doctors
  app.get("/api/doctors", async (req, res) => {
    const hospitalId = req.query.hospitalId ? parseInt(req.query.hospitalId as string) : undefined;
    const specialty = req.query.specialty as string | undefined;
    
    try {
      if (hospitalId) {
        const doctors = await storage.getDoctorsByHospital(hospitalId);
        res.json(doctors);
      } else if (specialty) {
        const doctors = await storage.getDoctorsBySpecialty(specialty);
        res.json(doctors);
      } else {
        const doctors = await storage.getDoctors();
        res.json(doctors);
      }
    } catch (error) {
      console.error("Error fetching doctors:", error);
      res.status(500).json({ message: "Failed to fetch doctors" });
    }
  });

  // Get a specific doctor
  app.get("/api/doctors/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const doctor = await storage.getDoctor(id);
      
      if (!doctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      res.json(doctor);
    } catch (error) {
      console.error("Error fetching doctor:", error);
      res.status(500).json({ message: "Failed to fetch doctor" });
    }
  });

  // Get all appointments
  app.get("/api/appointments", async (req, res) => {
    try {
      const appointments = await storage.getAppointments();
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  // Get booked time slots
  app.get("/api/appointments/booked-slots", async (req, res) => {
    try {
      const bookedSlots = await storage.getBookedSlots();
      res.json(bookedSlots);
    } catch (error) {
      console.error("Error fetching booked slots:", error);
      res.status(500).json({ message: "Failed to fetch booked slots" });
    }
  });

  // Get a specific appointment
  app.get("/api/appointments/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      res.json(appointment);
    } catch (error) {
      console.error("Error fetching appointment:", error);
      res.status(500).json({ message: "Failed to fetch appointment" });
    }
  });

  // Create a new appointment
  app.post("/api/appointments", async (req, res) => {
    try {
      // Validate the request body
      const validatedData = insertAppointmentSchema.parse(req.body);
      
      // Check if the time slot is available
      const bookedSlots = await storage.getBookedSlots();
      const isSlotBooked = bookedSlots.some(
        slot => 
          slot.doctorId === validatedData.doctorId && 
          slot.appointmentDate === validatedData.appointmentDate && 
          slot.appointmentTime === validatedData.appointmentTime
      );
      
      if (isSlotBooked) {
        return res.status(400).json({ 
          message: "This time slot is already booked. Please select another time." 
        });
      }
      
      // Create the appointment
      const newAppointment = await storage.createAppointment(validatedData);
      res.status(201).json(newAppointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid appointment data", 
          errors: error.errors 
        });
      }
      
      console.error("Error creating appointment:", error);
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  // Update an appointment
  app.patch("/api/appointments/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Validate the update data
      const updatedData = req.body;
      
      // Check if the new time slot is available (if changing date/time)
      if (updatedData.appointmentDate || updatedData.appointmentTime) {
        const bookedSlots = await storage.getBookedSlots();
        const isSlotBooked = bookedSlots.some(
          slot => 
            slot.doctorId === (updatedData.doctorId || appointment.doctorId) && 
            slot.appointmentDate === (updatedData.appointmentDate || appointment.appointmentDate) && 
            slot.appointmentTime === (updatedData.appointmentTime || appointment.appointmentTime) &&
            // Exclude the current appointment from the check
            !(slot.doctorId === appointment.doctorId && 
              slot.appointmentDate === appointment.appointmentDate && 
              slot.appointmentTime === appointment.appointmentTime)
        );
        
        if (isSlotBooked) {
          return res.status(400).json({ 
            message: "This time slot is already booked. Please select another time." 
          });
        }
      }
      
      const updatedAppointment = await storage.updateAppointment(id, updatedData);
      res.json(updatedAppointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  // Cancel/delete an appointment
  app.delete("/api/appointments/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Instead of deleting, update the status to "cancelled"
      const updatedAppointment = await storage.updateAppointment(id, { status: "cancelled" });
      res.json({ message: "Appointment cancelled successfully" });
    } catch (error) {
      console.error("Error cancelling appointment:", error);
      res.status(500).json({ message: "Failed to cancel appointment" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
